// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x000 : Control signals
//         bit 0  - ap_start (Read/Write/COH)
//         bit 1  - ap_done (Read/COR)
//         bit 2  - ap_idle (Read)
//         bit 3  - ap_ready (Read/COR)
//         bit 7  - auto_restart (Read/Write)
//         bit 9  - interrupt (Read)
//         others - reserved
// 0x004 : Global Interrupt Enable Register
//         bit 0  - Global Interrupt Enable (Read/Write)
//         others - reserved
// 0x008 : IP Interrupt Enable Register (Read/Write)
//         bit 0 - enable ap_done interrupt (Read/Write)
//         bit 1 - enable ap_ready interrupt (Read/Write)
//         others - reserved
// 0x00c : IP Interrupt Status Register (Read/TOW)
//         bit 0 - ap_done (Read/TOW)
//         bit 1 - ap_ready (Read/TOW)
//         others - reserved
// 0x010 : Data signal of ps_J
//         bit 31~0 - ps_J[31:0] (Read/Write)
// 0x014 : Data signal of ps_J
//         bit 31~0 - ps_J[63:32] (Read/Write)
// 0x018 : reserved
// 0x01c : Data signal of ps_J_out
//         bit 31~0 - ps_J_out[31:0] (Read/Write)
// 0x020 : Data signal of ps_J_out
//         bit 31~0 - ps_J_out[63:32] (Read/Write)
// 0x024 : reserved
// 0x028 : Data signal of c_0
//         bit 15~0 - c_0[15:0] (Read/Write)
//         others   - reserved
// 0x02c : reserved
// 0x030 : Data signal of dt
//         bit 15~0 - dt[15:0] (Read/Write)
//         others   - reserved
// 0x034 : reserved
// 0x400 ~
// 0x7ff : Memory 'ps_x' (512 * 16b)
//         Word n : bit [15: 0] - ps_x[2n]
//                  bit [31:16] - ps_x[2n+1]
// 0x800 ~
// 0xbff : Memory 'ps_y' (512 * 16b)
//         Word n : bit [15: 0] - ps_y[2n]
//                  bit [31:16] - ps_y[2n+1]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XDSB_CONTROL_ADDR_AP_CTRL       0x000
#define XDSB_CONTROL_ADDR_GIE           0x004
#define XDSB_CONTROL_ADDR_IER           0x008
#define XDSB_CONTROL_ADDR_ISR           0x00c
#define XDSB_CONTROL_ADDR_PS_J_DATA     0x010
#define XDSB_CONTROL_BITS_PS_J_DATA     64
#define XDSB_CONTROL_ADDR_PS_J_OUT_DATA 0x01c
#define XDSB_CONTROL_BITS_PS_J_OUT_DATA 64
#define XDSB_CONTROL_ADDR_C_0_DATA      0x028
#define XDSB_CONTROL_BITS_C_0_DATA      16
#define XDSB_CONTROL_ADDR_DT_DATA       0x030
#define XDSB_CONTROL_BITS_DT_DATA       16
#define XDSB_CONTROL_ADDR_PS_X_BASE     0x400
#define XDSB_CONTROL_ADDR_PS_X_HIGH     0x7ff
#define XDSB_CONTROL_WIDTH_PS_X         16
#define XDSB_CONTROL_DEPTH_PS_X         512
#define XDSB_CONTROL_ADDR_PS_Y_BASE     0x800
#define XDSB_CONTROL_ADDR_PS_Y_HIGH     0xbff
#define XDSB_CONTROL_WIDTH_PS_Y         16
#define XDSB_CONTROL_DEPTH_PS_Y         512

