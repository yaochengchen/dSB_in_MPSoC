// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x0000 : Control signals
//          bit 0  - ap_start (Read/Write/COH)
//          bit 1  - ap_done (Read/COR)
//          bit 2  - ap_idle (Read)
//          bit 3  - ap_ready (Read/COR)
//          bit 7  - auto_restart (Read/Write)
//          bit 9  - interrupt (Read)
//          others - reserved
// 0x0004 : Global Interrupt Enable Register
//          bit 0  - Global Interrupt Enable (Read/Write)
//          others - reserved
// 0x0008 : IP Interrupt Enable Register (Read/Write)
//          bit 0 - enable ap_done interrupt (Read/Write)
//          bit 1 - enable ap_ready interrupt (Read/Write)
//          others - reserved
// 0x000c : IP Interrupt Status Register (Read/TOW)
//          bit 0 - ap_done (Read/TOW)
//          bit 1 - ap_ready (Read/TOW)
//          others - reserved
// 0x0010 : Data signal of ps_J
//          bit 31~0 - ps_J[31:0] (Read/Write)
// 0x0014 : Data signal of ps_J
//          bit 31~0 - ps_J[63:32] (Read/Write)
// 0x0018 : reserved
// 0x001c : Data signal of c_0
//          bit 15~0 - c_0[15:0] (Read/Write)
//          others   - reserved
// 0x0020 : reserved
// 0x0024 : Data signal of dt
//          bit 15~0 - dt[15:0] (Read/Write)
//          others   - reserved
// 0x0028 : reserved
// 0x0800 ~
// 0x0fff : Memory 'ps_x' (1024 * 16b)
//          Word n : bit [15: 0] - ps_x[2n]
//                   bit [31:16] - ps_x[2n+1]
// 0x1000 ~
// 0x17ff : Memory 'ps_y' (1024 * 16b)
//          Word n : bit [15: 0] - ps_y[2n]
//                   bit [31:16] - ps_y[2n+1]
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XDSB_CONTROL_ADDR_AP_CTRL   0x0000
#define XDSB_CONTROL_ADDR_GIE       0x0004
#define XDSB_CONTROL_ADDR_IER       0x0008
#define XDSB_CONTROL_ADDR_ISR       0x000c
#define XDSB_CONTROL_ADDR_PS_J_DATA 0x0010
#define XDSB_CONTROL_BITS_PS_J_DATA 64
#define XDSB_CONTROL_ADDR_C_0_DATA  0x001c
#define XDSB_CONTROL_BITS_C_0_DATA  16
#define XDSB_CONTROL_ADDR_DT_DATA   0x0024
#define XDSB_CONTROL_BITS_DT_DATA   16
#define XDSB_CONTROL_ADDR_PS_X_BASE 0x0800
#define XDSB_CONTROL_ADDR_PS_X_HIGH 0x0fff
#define XDSB_CONTROL_WIDTH_PS_X     16
#define XDSB_CONTROL_DEPTH_PS_X     1024
#define XDSB_CONTROL_ADDR_PS_Y_BASE 0x1000
#define XDSB_CONTROL_ADDR_PS_Y_HIGH 0x17ff
#define XDSB_CONTROL_WIDTH_PS_Y     16
#define XDSB_CONTROL_DEPTH_PS_Y     1024

