// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2023.1 (64-bit)
// Tool Version Limit: 2023.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xdsb.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XDsb_CfgInitialize(XDsb *InstancePtr, XDsb_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XDsb_Start(XDsb *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsb_ReadReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_AP_CTRL) & 0x80;
    XDsb_WriteReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XDsb_IsDone(XDsb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsb_ReadReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XDsb_IsIdle(XDsb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsb_ReadReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XDsb_IsReady(XDsb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsb_ReadReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XDsb_EnableAutoRestart(XDsb *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsb_WriteReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XDsb_DisableAutoRestart(XDsb *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsb_WriteReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_AP_CTRL, 0);
}

void XDsb_Set_ps_J(XDsb *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsb_WriteReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_PS_J_DATA, (u32)(Data));
    XDsb_WriteReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_PS_J_DATA + 4, (u32)(Data >> 32));
}

u64 XDsb_Get_ps_J(XDsb *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsb_ReadReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_PS_J_DATA);
    Data += (u64)XDsb_ReadReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_PS_J_DATA + 4) << 32;
    return Data;
}

void XDsb_Set_c_0(XDsb *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsb_WriteReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_C_0_DATA, Data);
}

u32 XDsb_Get_c_0(XDsb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsb_ReadReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_C_0_DATA);
    return Data;
}

void XDsb_Set_dt(XDsb *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsb_WriteReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_DT_DATA, Data);
}

u32 XDsb_Get_dt(XDsb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XDsb_ReadReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_DT_DATA);
    return Data;
}

u32 XDsb_Get_ps_x_BaseAddress(XDsb *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDSB_CONTROL_ADDR_PS_X_BASE);
}

u32 XDsb_Get_ps_x_HighAddress(XDsb *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDSB_CONTROL_ADDR_PS_X_HIGH);
}

u32 XDsb_Get_ps_x_TotalBytes(XDsb *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XDSB_CONTROL_ADDR_PS_X_HIGH - XDSB_CONTROL_ADDR_PS_X_BASE + 1);
}

u32 XDsb_Get_ps_x_BitWidth(XDsb *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDSB_CONTROL_WIDTH_PS_X;
}

u32 XDsb_Get_ps_x_Depth(XDsb *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDSB_CONTROL_DEPTH_PS_X;
}

u32 XDsb_Write_ps_x_Words(XDsb *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDSB_CONTROL_ADDR_PS_X_HIGH - XDSB_CONTROL_ADDR_PS_X_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XDSB_CONTROL_ADDR_PS_X_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XDsb_Read_ps_x_Words(XDsb *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDSB_CONTROL_ADDR_PS_X_HIGH - XDSB_CONTROL_ADDR_PS_X_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XDSB_CONTROL_ADDR_PS_X_BASE + (offset + i)*4);
    }
    return length;
}

u32 XDsb_Write_ps_x_Bytes(XDsb *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDSB_CONTROL_ADDR_PS_X_HIGH - XDSB_CONTROL_ADDR_PS_X_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XDSB_CONTROL_ADDR_PS_X_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XDsb_Read_ps_x_Bytes(XDsb *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDSB_CONTROL_ADDR_PS_X_HIGH - XDSB_CONTROL_ADDR_PS_X_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XDSB_CONTROL_ADDR_PS_X_BASE + offset + i);
    }
    return length;
}

u32 XDsb_Get_ps_y_BaseAddress(XDsb *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDSB_CONTROL_ADDR_PS_Y_BASE);
}

u32 XDsb_Get_ps_y_HighAddress(XDsb *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (InstancePtr->Control_BaseAddress + XDSB_CONTROL_ADDR_PS_Y_HIGH);
}

u32 XDsb_Get_ps_y_TotalBytes(XDsb *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return (XDSB_CONTROL_ADDR_PS_Y_HIGH - XDSB_CONTROL_ADDR_PS_Y_BASE + 1);
}

u32 XDsb_Get_ps_y_BitWidth(XDsb *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDSB_CONTROL_WIDTH_PS_Y;
}

u32 XDsb_Get_ps_y_Depth(XDsb *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDSB_CONTROL_DEPTH_PS_Y;
}

u32 XDsb_Write_ps_y_Words(XDsb *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDSB_CONTROL_ADDR_PS_Y_HIGH - XDSB_CONTROL_ADDR_PS_Y_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(int *)(InstancePtr->Control_BaseAddress + XDSB_CONTROL_ADDR_PS_Y_BASE + (offset + i)*4) = *(data + i);
    }
    return length;
}

u32 XDsb_Read_ps_y_Words(XDsb *InstancePtr, int offset, word_type *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length)*4 > (XDSB_CONTROL_ADDR_PS_Y_HIGH - XDSB_CONTROL_ADDR_PS_Y_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(int *)(InstancePtr->Control_BaseAddress + XDSB_CONTROL_ADDR_PS_Y_BASE + (offset + i)*4);
    }
    return length;
}

u32 XDsb_Write_ps_y_Bytes(XDsb *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDSB_CONTROL_ADDR_PS_Y_HIGH - XDSB_CONTROL_ADDR_PS_Y_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(char *)(InstancePtr->Control_BaseAddress + XDSB_CONTROL_ADDR_PS_Y_BASE + offset + i) = *(data + i);
    }
    return length;
}

u32 XDsb_Read_ps_y_Bytes(XDsb *InstancePtr, int offset, char *data, int length) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr -> IsReady == XIL_COMPONENT_IS_READY);

    int i;

    if ((offset + length) > (XDSB_CONTROL_ADDR_PS_Y_HIGH - XDSB_CONTROL_ADDR_PS_Y_BASE + 1))
        return 0;

    for (i = 0; i < length; i++) {
        *(data + i) = *(char *)(InstancePtr->Control_BaseAddress + XDSB_CONTROL_ADDR_PS_Y_BASE + offset + i);
    }
    return length;
}

void XDsb_InterruptGlobalEnable(XDsb *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsb_WriteReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_GIE, 1);
}

void XDsb_InterruptGlobalDisable(XDsb *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsb_WriteReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_GIE, 0);
}

void XDsb_InterruptEnable(XDsb *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDsb_ReadReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_IER);
    XDsb_WriteReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_IER, Register | Mask);
}

void XDsb_InterruptDisable(XDsb *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XDsb_ReadReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_IER);
    XDsb_WriteReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_IER, Register & (~Mask));
}

void XDsb_InterruptClear(XDsb *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XDsb_WriteReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_ISR, Mask);
}

u32 XDsb_InterruptGetEnabled(XDsb *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDsb_ReadReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_IER);
}

u32 XDsb_InterruptGetStatus(XDsb *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XDsb_ReadReg(InstancePtr->Control_BaseAddress, XDSB_CONTROL_ADDR_ISR);
}

